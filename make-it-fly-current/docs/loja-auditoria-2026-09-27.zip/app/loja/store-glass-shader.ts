// The glass stays transparent to the DOM. Optical detail comes from a studio
// environment sampled with reflected/refracted rays, not from an opaque backdrop.
export const glassVertexShader = /* glsl */ `
  uniform float uTime;
  uniform vec2 uPointer;
  uniform float uImpulse;
  varying vec3 vWorldPosition;
  varying vec3 vWorldNormal;
  varying vec3 vObjectPosition;

  vec3 deform(vec3 n) {
    float t = uTime;
    float swell = sin(n.x * 2.7 + t * .42) * cos(n.y * 2.4 - t * .31) * sin(n.z * 2.5 + t * .25);
    float tide = sin(n.y * 3.9 + n.z * 2.8 + t * .34) * cos(n.x * 3.4 - t * .27);
    float ripple = sin(n.x * 8. + n.y * 5. - t * .38) * cos(n.z * 7. + t * .32);
    vec3 touch = normalize(vec3(uPointer * .75, 1.));
    float proximity = exp(-7.5 * dot(n - touch, n - touch));
    float radius = 1. + swell * .043 + tide * .018 + ripple * .0035;
    radius += proximity * uImpulse * .035;
    vec3 p = n * radius;
    p.x += sin(t * .23) * n.y * .016;
    p.y *= 1.015 + sin(t * .32) * .012;
    return p;
  }

  void main() {
    vec3 n = normalize(position);
    vec3 tangent = normalize(cross(abs(n.y) < .9 ? vec3(0., 1., 0.) : vec3(1., 0., 0.), n));
    vec3 bitangent = cross(n, tangent);
    float e = .004;
    vec3 dt = deform(normalize(n + tangent * e)) - deform(normalize(n - tangent * e));
    vec3 db = deform(normalize(n + bitangent * e)) - deform(normalize(n - bitangent * e));
    vec3 p = deform(n);
    vec4 world = modelMatrix * vec4(p, 1.);
    vWorldPosition = world.xyz;
    vWorldNormal = normalize(mat3(modelMatrix) * normalize(cross(dt, db)));
    vObjectPosition = p;
    gl_Position = projectionMatrix * viewMatrix * world;
  }
`;

export const glassFragmentShader = /* glsl */ `
  uniform float uTime;
  varying vec3 vWorldPosition;
  varying vec3 vWorldNormal;
  varying vec3 vObjectPosition;

  // Tall softboxes and dark studio flags produce thin moving reflections.
  float softbox(vec3 ray, vec3 axis, vec3 up, vec2 size) {
    vec3 side = normalize(cross(axis, up));
    vec3 vertical = cross(side, axis);
    float facing = dot(ray, axis);
    vec2 uv = vec2(dot(ray, side), dot(ray, vertical)) / max(.1, facing);
    vec2 box = smoothstep(size, size * 1.4, abs(uv));
    return (1. - box.x) * (1. - box.y) * smoothstep(.0, .3, facing);
  }

  vec3 studio(vec3 ray) {
    vec3 color = mix(vec3(.68, .77, .82), vec3(.98, .99, 1.), smoothstep(-.6, .7, ray.y));
    float leftFlag = softbox(ray, normalize(vec3(-.85, .2, .55)), vec3(0., 1., 0.), vec2(.16, 1.1));
    float rightFlag = softbox(ray, normalize(vec3(.8, -.15, -.6)), vec3(0., 1., 0.), vec2(.1, .7));
    color = mix(color, vec3(.08, .16, .22), leftFlag * .88);
    color = mix(color, vec3(.24, .35, .42), rightFlag * .7);
    float key = softbox(ray, normalize(vec3(-.55, .75, .65)), vec3(0., 1., 0.), vec2(.12, .68));
    float strip = softbox(ray, normalize(vec3(.72, .18, .7)), vec3(0., 1., 0.), vec2(.035, .75));
    return color + vec3(key * .9 + strip * 1.2);
  }

  void main() {
    vec3 N = normalize(vWorldNormal);
    vec3 V = normalize(cameraPosition - vWorldPosition);
    float facing = clamp(dot(N, V), .0, 1.);
    float fresnel = .0204 + .9796 * pow(1. - facing, 5.);
    vec3 reflected = reflect(-V, N);

    // Approximate both interfaces of a water volume (IOR 1.333), not a flat film.
    vec3 entryRay = refract(-V, N, 1. / 1.333);
    float chord = max(.05, -2. * dot(N, entryRay));
    vec3 exitNormal = normalize(N + entryRay * chord);
    vec3 exitRay = refract(entryRay, -exitNormal, 1.333);
    if (dot(exitRay, exitRay) < .001) exitRay = reflected;
    vec3 transmission = studio(normalize(exitRay));
    vec3 reflection = studio(reflected);

    float rim = pow(1. - facing, 2.7);
    float lowerEdge = 1. - smoothstep(-.9, .25, vObjectPosition.y);
    float innerRim = exp(-pow((facing - .32) / .105, 2.));
    float thinRim = exp(-pow((facing - .11) / .048, 2.));
    float flowing = sin(facing * 34. + vObjectPosition.y * 3. + sin(uTime * .3 + vObjectPosition.x * 4.));
    float caustic = pow(max(0., flowing), 10.) * rim * .11;

    vec3 color = mix(vec3(.86, .93, .97), transmission, .42);
    color = mix(color, reflection, .3 + fresnel * .7);
    color -= vec3(.3, .22, .13) * innerRim * (.35 + lowerEdge * .65);
    color -= vec3(.22, .16, .1) * thinRim;
    color += caustic;
    // Small dispersion only at the rim; the water core remains colourless.
    color += vec3(.015, .006, -.008) * sin(reflected.y * 17.) * rim;
    float highlight = max(0., max(reflection.r, max(reflection.g, reflection.b)) - 1.);
    float flag = 1. - min(reflection.r, min(reflection.g, reflection.b));
    float alpha = .045 + rim * .56 + innerRim * .25 + thinRim * .2;
    alpha += max(0., flag) * .2;
    alpha += highlight * .35;
    gl_FragColor = vec4(max(color, vec3(0.)), clamp(alpha, .035, .9));
    #include <colorspace_fragment>
  }
`;
