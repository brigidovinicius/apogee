"use client";

import { useEffect, useRef } from "react";

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));
// Exponential damping uses elapsed seconds so 60 Hz and 120 Hz feel the same.
const damp = (value: number, target: number, speed: number, delta: number) =>
  value + (target - value) * -Math.expm1(-speed * delta);

/** Keep scrolling native; smooth the objects and light, never the document itself. */
export function useStoreMotion() {
  const root = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = root.current;
    if (!element) return;
    const page = element;

    const reduced = matchMedia("(prefers-reduced-motion: reduce)");
    const desktop = matchMedia("(min-width: 761px) and (hover: hover) and (pointer: fine)");
    const cursor = page.querySelector<HTMLElement>("[data-store-cursor]");
    const html = document.documentElement;
    const previousBehavior = html.style.scrollBehavior;
    const cards = Array.from(page.querySelectorAll<HTMLElement>("[data-store-slot]")).map((slot, index) => ({
      slot,
      card: slot.querySelector<HTMLElement>("[data-store-card]"),
      visible: false,
      left: 0,
      top: 0,
      width: 1,
      height: 1,
      time: index * 2.73,
      floatX: 0,
      floatY: 0,
      floatTurn: 0,
      turn: 0,
      lift: 0,
      tiltX: 0,
      tiltY: 0,
      hover: 0,
      glintX: 50,
      glintY: 40,
    }));

    let frame = 0;
    let lastTime = 0;
    let measureNeeded = true;
    let hitTestNeeded = false;
    let viewportHeight = innerHeight;
    let maxScroll = 1;
    let progress = 0;
    let orbX = 0;
    let orbY = 0;
    let pointerX = 0;
    let pointerY = 0;
    let cursorX = 0;
    let cursorY = 0;
    let hasPointer = false;
    let hovered: HTMLElement | null = null;
    let modalOpen = Boolean(page.querySelector("dialog[open]"));

    const requestFrame = () => {
      if (!frame && !document.hidden && !modalOpen) frame = requestAnimationFrame(draw);
    };

    function draw(time: number) {
      frame = 0;
      const delta = Math.min((time - (lastTime || time - 16.67)) / 1000, 0.05);
      lastTime = time;
      const scroll = window.scrollY;
      const animate = !reduced.matches && !modalOpen && desktop.matches;

      // Read layout together, and only after layout/viewport changes. The slot
      // itself never transforms, so its document coordinates remain stable.
      if (measureNeeded) {
        viewportHeight = innerHeight;
        maxScroll = Math.max(1, html.scrollHeight - viewportHeight);
        for (const state of cards) {
          const rect = state.slot.getBoundingClientRect();
          state.left = rect.left;
          state.top = rect.top + scroll;
          state.width = rect.width;
          state.height = rect.height;
        }
        measureNeeded = false;
      }
      if (hitTestNeeded && hasPointer && animate) {
        hovered = document.elementFromPoint(pointerX, pointerY)?.closest<HTMLElement>("[data-store-card]") ?? null;
      }
      hitTestNeeded = false;

      const targetProgress = clamp(scroll / maxScroll, 0, 1);
      progress = reduced.matches ? targetProgress : damp(progress, targetProgress, 8, delta);
      const targetOrbX = animate ? Math.sin(progress * Math.PI * 3) * 16 : 0;
      const targetOrbY = animate ? Math.sin(progress * Math.PI * 2) * 9 : 0;
      // A short second damping pass rounds trajectory changes without a CSS
      // transition being restarted on every incoming scroll event.
      orbX = reduced.matches ? 0 : damp(orbX, targetOrbX, 5, delta);
      orbY = reduced.matches ? 0 : damp(orbY, targetOrbY, 5, delta);
      let needsFrame = Math.abs(progress - targetProgress) > 0.0001
        || Math.abs(orbX - targetOrbX) + Math.abs(orbY - targetOrbY) > 0.005;

      // All DOM writes occur after the measurement/hit-test phase.
      page.dataset.scrolled = String(scroll > 20);
      page.dataset.cursorActive = String(animate && hasPointer && Boolean(hovered));
      page.style.setProperty("--scroll-progress", progress.toFixed(5));
      page.style.setProperty("--orb-x", `${orbX.toFixed(3)}vw`);
      page.style.setProperty("--orb-y", `${orbY.toFixed(3)}vh`);

      if (cursor && animate && hasPointer) {
        cursorX = damp(cursorX, pointerX + 18, 19, delta);
        cursorY = damp(cursorY, pointerY + 18, 19, delta);
        cursor.style.transform = `translate3d(${cursorX.toFixed(2)}px,${cursorY.toFixed(2)}px,0)`;
        needsFrame ||= Math.abs(cursorX - pointerX - 18) + Math.abs(cursorY - pointerY - 18) > 0.1;
      }

      for (const state of cards) {
        if (!state.visible || !state.card) continue;
        const isHovered = animate && hovered === state.card;
        const phase = clamp((state.top + state.height / 2 - scroll - viewportHeight / 2) / viewportHeight, -1, 1);
        const localX = isHovered ? clamp((pointerX - state.left) / state.width, 0, 1) : 0.5;
        const localY = isHovered ? clamp((pointerY - state.top + scroll) / state.height, 0, 1) : 0.4;

        if (animate) state.time += delta;
        // Offset frequencies make a slow looping orbit, not a diagonal seesaw.
        const floatX = animate ? Math.sin(state.time * 0.53) * 5 + Math.sin(state.time * 0.29) * 2 : 0;
        const floatY = animate ? Math.cos(state.time * 0.67) * 7 : 0;
        const floatTurn = animate ? Math.sin(state.time * 0.39) * 0.32 : 0;
        const blend = reduced.matches ? 1 : -Math.expm1(-8 * delta);
        state.floatX += (floatX - state.floatX) * blend;
        state.floatY += (floatY - state.floatY) * blend;
        state.floatTurn += (floatTurn - state.floatTurn) * blend;
        state.turn += ((animate ? phase * 10 : 0) - state.turn) * blend;
        state.lift += ((animate ? phase * -18 : 0) - state.lift) * blend;
        state.hover = damp(state.hover, isHovered ? 1 : 0, 10, delta);
        state.tiltX = damp(state.tiltX, isHovered ? (localX - 0.5) * 9 : 0, 11, delta);
        state.tiltY = damp(state.tiltY, isHovered ? (localY - 0.5) * -8 : 0, 11, delta);
        state.glintX = damp(state.glintX, localX * 100, 9, delta);
        state.glintY = damp(state.glintY, localY * 100, 9, delta);

        state.slot.style.setProperty("--float-x", `${state.floatX.toFixed(2)}px`);
        state.slot.style.setProperty("--float-y", `${state.floatY.toFixed(2)}px`);
        state.slot.style.setProperty("--float-turn", `${state.floatTurn.toFixed(3)}deg`);
        state.slot.style.setProperty("--product-turn", `${state.turn.toFixed(3)}deg`);
        state.slot.style.setProperty("--product-lift", `${state.lift.toFixed(2)}px`);
        state.card.style.setProperty("--pointer-x", `${state.tiltX.toFixed(3)}deg`);
        state.card.style.setProperty("--pointer-y", `${state.tiltY.toFixed(3)}deg`);
        state.card.style.setProperty("--hover-lift", `${(state.hover * -8).toFixed(2)}px`);
        state.card.style.setProperty("--hover-scale", (1 + state.hover * 0.035).toFixed(4));
        state.card.style.setProperty("--hover-progress", state.hover.toFixed(4));
        state.card.style.setProperty("--glint-x", `${state.glintX.toFixed(2)}%`);
        state.card.style.setProperty("--glint-y", `${state.glintY.toFixed(2)}%`);
        needsFrame ||= animate;
      }

      if (needsFrame && !reduced.matches && !modalOpen) requestFrame();
      else lastTime = 0;
    }

    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        const state = cards.find(({ slot }) => slot === entry.target);
        if (!state) continue;
        state.visible = entry.isIntersecting;
        state.slot.dataset.inView = String(entry.isIntersecting);
        if (entry.isIntersecting) state.slot.dataset.revealed = "true";
      }
      requestFrame();
    }, { threshold: 0, rootMargin: "100px 0px" });
    cards.forEach(({ slot }) => observer.observe(slot));

    const onScroll = () => {
      hitTestNeeded = true;
      requestFrame();
    };
    const onResize = () => {
      measureNeeded = true;
      requestFrame();
    };
    const resizeObserver = new ResizeObserver(onResize);
    resizeObserver.observe(page);
    const resetPointer = () => {
      hovered = null;
      hasPointer = false;
      page.dataset.cursorActive = "false";
      requestFrame();
    };
    const onPointer = (event: PointerEvent) => {
      if (!desktop.matches || reduced.matches || modalOpen || event.pointerType === "touch") return;
      pointerX = event.clientX;
      pointerY = event.clientY;
      if (!hasPointer) {
        cursorX = pointerX + 18;
        cursorY = pointerY + 18;
        hasPointer = true;
      }
      const target = event.target instanceof Element ? event.target : null;
      hovered = target?.closest<HTMLElement>("[data-store-card]") ?? null;
      requestFrame();
    };
    const syncPause = () => {
      modalOpen = Boolean(page.querySelector("dialog[open]"));
      page.dataset.motionPaused = String(modalOpen || document.hidden || reduced.matches);
      page.dataset.pageHidden = String(document.hidden);
      if (modalOpen || document.hidden) {
        cancelAnimationFrame(frame);
        frame = 0;
        lastTime = 0;
        hovered = null;
        hasPointer = false;
        page.dataset.cursorActive = "false";
      } else {
        measureNeeded = true;
        requestFrame();
      }
    };
    const dialogObserver = new MutationObserver(syncPause);
    dialogObserver.observe(page, { subtree: true, attributes: true, attributeFilter: ["open"] });
    const onPreference = () => {
      html.style.scrollBehavior = reduced.matches ? "auto" : "smooth";
      resetPointer();
      syncPause();
    };

    page.dataset.motionReady = "true";
    onPreference();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onResize, { passive: true });
    window.addEventListener("blur", resetPointer);
    window.addEventListener("keydown", resetPointer);
    document.addEventListener("visibilitychange", syncPause);
    page.addEventListener("pointermove", onPointer, { passive: true });
    page.addEventListener("pointerleave", resetPointer);
    reduced.addEventListener("change", onPreference);
    desktop.addEventListener("change", onPreference);

    return () => {
      observer.disconnect();
      resizeObserver.disconnect();
      dialogObserver.disconnect();
      cancelAnimationFrame(frame);
      html.style.scrollBehavior = previousBehavior;
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("blur", resetPointer);
      window.removeEventListener("keydown", resetPointer);
      document.removeEventListener("visibilitychange", syncPause);
      page.removeEventListener("pointermove", onPointer);
      page.removeEventListener("pointerleave", resetPointer);
      reduced.removeEventListener("change", onPreference);
      desktop.removeEventListener("change", onPreference);
    };
  }, []);

  return root;
}
