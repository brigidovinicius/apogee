import type { Metadata } from "next";
import { StoreExperience } from "./store-experience";

export const metadata: Metadata = {
  title: "Loja | Make it fly",
  description:
    "Peças, objetos e edições especiais da comunidade Make it fly — primeira coleção em desenvolvimento.",
};

export default function StorePage() {
  return <StoreExperience />;
}
